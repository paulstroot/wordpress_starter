<?php
/**
 * All of our functions live in the "library/functions/ directory for ease of development
 */
require get_template_directory() . '/library/functions/general.php';
require get_template_directory() . '/library/functions/gutenberg.php';
require get_template_directory() . '/library/functions/scripts-and-enqueing.php';
require get_template_directory() . '/library/functions/thumbnails.php';
require get_template_directory() . '/library/functions/team-post-type.php';
require get_template_directory() . '/library/functions/menus.php';
require get_template_directory() . '/library/functions/customizer-contactinfo.php';
require get_template_directory() . '/library/functions/customizer-socialmedia.php';

